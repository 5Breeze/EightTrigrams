#include "data_storage.h"     //包含需要的头文件

void Write_Float_to_EEPROM(float data, uint8_t floatIndex)
{
    uint32_t address = 0x08080000 + (floatIndex * sizeof(float)); // 计算目标地址
    uint32_t temp;
		memcpy(&temp, &data, sizeof(float));
	 while ((FLASH->SR & FLASH_SR_BSY) != 0) /* (1) */
 {
 /* For robust implementation, add here time-out management */
 }
 if ((FLASH->PECR & FLASH_PECR_PELOCK) != 0) /* (2) */
 {
  FLASH->PEKEYR = FLASH_PEKEY1; /* (3) */
  FLASH->PEKEYR = FLASH_PEKEY2;
 }
 *(uint32_t *)(address) = temp;
 while ((FLASH->SR & FLASH_SR_BSY) != 0) /* (1) */
 {
  /* For robust implementation, add here time-out management */
 }
 FLASH->PECR |= FLASH_PECR_PELOCK; /* (2) */
}

float Read_Float_from_EEPROM(uint8_t floatIndex)
{
    uint32_t address = 0x08080000 + (floatIndex * sizeof(float)); // 计算目标地址
    uint32_t temp;
    float data;

    temp = *(uint32_t*)address;

    // 将 uint32_t 转换回 float
    memcpy(&data, &temp, sizeof(float));

    return data;
}