#include "data_storage.h"

// 存储数据的函数
HAL_StatusTypeDef store_float_data(const float *data) {
    HAL_StatusTypeDef status;
    uint32_t address = DATA_EEPROM_START_ADDR;
    uint32_t *p_data = (uint32_t *)data;

    // 解锁数据EEPROM
    status = HAL_FLASHEx_DATAEEPROM_Unlock();
    if (status != HAL_OK) {
        return status;
    }

    // 擦除数据EEPROM中的数据
    for (int i = 0; i < NUM_FLOATS; i++) {
        status = HAL_FLASHEx_DATAEEPROM_Erase(address + i * sizeof(float));
        if (status != HAL_OK) {
            HAL_FLASHEx_DATAEEPROM_Lock();
            return status;
        }
    }

    // 编程数据EEPROM
    for (int i = 0; i < NUM_FLOATS; i++) {
        status = HAL_FLASHEx_DATAEEPROM_Program(FLASH_TYPEPROGRAMDATA_WORD, address + i * sizeof(float), p_data[i]);
        if (status != HAL_OK) {
            HAL_FLASHEx_DATAEEPROM_Lock();
            return status;
        }
    }

    // 锁定数据EEPROM
    HAL_FLASHEx_DATAEEPROM_Lock();

    return HAL_OK;
}

// 读取数据的函数
HAL_StatusTypeDef read_float_data(float *data) {
    uint32_t address = DATA_EEPROM_START_ADDR;
    uint32_t *p_data = (uint32_t *)data;

    for (int i = 0; i < NUM_FLOATS; i++) {
        *p_data++ = *(uint32_t *)(address + i * sizeof(float));
    }

    return HAL_OK;
}