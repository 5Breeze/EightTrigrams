#include "matrix.h"

// 矩阵乘法
void matrix_mul(float A[MATRIX_SIZE][MATRIX_SIZE], float B[MATRIX_SIZE][MATRIX_SIZE], float C[MATRIX_SIZE][MATRIX_SIZE], int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = 0;
            for (int k = 0; k < size; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// 矩阵求逆
void matrix_inverse(float src[MATRIX_SIZE][MATRIX_SIZE], float res[MATRIX_SIZE][MATRIX_SIZE], int size) {
    int i, j, k, principal;
    float L[MATRIX_SIZE][MATRIX_SIZE] = {0};
    float U[MATRIX_SIZE][MATRIX_SIZE] = {0};
    float tmp[MATRIX_SIZE][MATRIX_SIZE];
    float Lsum, Usum, p, Max;

    // 复制输入矩阵到临时矩阵
    memcpy(tmp, src, sizeof(float) * size * size);

    // 初始化 L 为单位矩阵
    for (i = 0; i < size; i++) {
        L[i][i] = 1.0f;
    }

    // 选主元并进行行交换
    for (j = 0; j < size; j++) {
        principal = j;
        Max = fabs(tmp[principal][j]);
        for (i = j + 1; i < size; i++) {
            if (fabs(tmp[i][j]) > Max) {
                principal = i;
                Max = fabs(tmp[i][j]);
            }
        }
        if (j != principal) {
            for (k = 0; k < size; k++) {
                p = tmp[principal][k];
                tmp[principal][k] = tmp[j][k];
                tmp[j][k] = p;
            }
        }
    }

    // 计算 L 和 U
    for (i = 0; i < size; i++) {
        for (j = 0; j < size; j++) {
            if (i <= j) {
                Usum = 0;
                for (k = 0; k < i; k++) {
                    Usum += L[i][k] * U[k][j];
                }
                U[i][j] = tmp[i][j] - Usum;
            } else {
                Lsum = 0;
                for (k = 0; k < j; k++) {
                    Lsum += L[i][k] * U[k][j];
                }
                L[i][j] = (tmp[i][j] - Lsum) / U[j][j];
            }
        }
    }

    // L 的逆
    for (i = 0; i < size; i++) {
        for (j = 0; j <= i; j++) {
            if (i == j) {
                L[i][j] = 1.0f / L[i][j];
            } else {
                Lsum = 0;
                for (k = j; k < i; k++) {
                    Lsum += L[i][k] * L[k][j];
                }
                L[i][j] = -Lsum / L[i][i];
            }
        }
    }

    // U 的逆
    for (j = size - 1; j >= 0; j--) {
        for (i = j; i >= 0; i--) {
            if (i == j) {
                U[i][j] = 1.0f / U[i][j];
            } else {
                Usum = 0;
                for (k = j; k >= i + 1; k--) {
                    Usum += U[i][k] * U[k][j];
                }
                U[i][j] = -Usum / U[i][i];
            }
        }
    }

    // 计算逆矩阵 res = U^-1 * L^-1
    matrix_mul(U, L, res, size);
}

// 矩阵与向量相乘
void matrix__mul(float matrix[MATRIX_SIZE][MATRIX_SIZE], float vector[MATRIX_SIZE], float result[MATRIX_SIZE]) {
    for (int i = 0; i < MATRIX_SIZE; i++) {
        result[i] = 0; // 初始化结果向量的第 i 个元素
        for (int j = 0; j < MATRIX_SIZE; j++) {
            result[i] += matrix[i][j] * vector[j]; // 计算矩阵第 i 行和向量的点积
        }
    }
}

// 统计参数
float calcAverages(const short* x, const short* y, const short* z, int num_points, float* params) {
    //1th
		long long sum_x = 0, sum_y = 0, sum_z = 0;
		//2th
    long long sum_xx = 0, sum_yy = 0, sum_zz = 0;
    long long sum_xy = 0, sum_xz = 0, sum_yz = 0;
	  //3th
		long long sum_xxx = 0, sum_yyy = 0, sum_zzz = 0;
		long long sum_xxy = 0, sum_xxz = 0, sum_xyy = 0;
		long long sum_xzz = 0, sum_yyz = 0, sum_yzz = 0;
		//4th
	  long long sum_yyyy = 0, sum_zzzz = 0, sum_xxyy = 0, sum_xxzz = 0, sum_yyzz = 0;
 
  	for (int i = 0; i < num_points; i++) {
				// 一次项
				sum_x += (long long) x[i];
			
				sum_y += (long long) y[i];
				sum_z += (long long) z[i];
		
				// 二次项
				sum_xx += (long long) x[i] * x[i];
				sum_yy += (long long) y[i] * y[i];
				sum_zz += (long long) z[i] * z[i];
				sum_xy += (long long) x[i] * y[i];
				sum_xz += (long long) x[i] * z[i];
				sum_yz += (long long) y[i] * z[i];
		
				// 三次项
				sum_xxx += (long long) x[i] * x[i] * x[i];
				sum_yyy += (long long) y[i] * y[i] * y[i];
				sum_zzz += (long long) z[i] * z[i] * z[i];
				sum_xxy += (long long) x[i] * x[i] * y[i];
				sum_xxz += (long long) x[i] * x[i] * z[i];
				sum_xyy += (long long) x[i] * y[i] * y[i];
				sum_xzz += (long long) x[i] * z[i] * z[i];
				sum_yyz += (long long) y[i] * y[i] * z[i];
				sum_yzz += (long long) y[i] * z[i] * z[i];
		
				// 四次项
				sum_yyyy += (long long) y[i] * y[i] * y[i] * y[i];
				sum_zzzz += (long long) z[i] * z[i] * z[i] * z[i];
				sum_xxyy += (long long) x[i] * x[i] * y[i] * y[i];
				sum_xxzz += (long long) x[i] * x[i] * z[i] * z[i];
				sum_yyzz += (long long) y[i] * y[i] * z[i] * z[i];
    }

    // 转换为浮点数平均值
    params[0] = sum_x / (float)num_points;    // x_avg
    params[1] = sum_y / (float)num_points;    // y_avg
    params[2] = sum_z / (float)num_points;    // z_avg
    params[3] = sum_xx / (float)num_points;   // xx_avg
    params[4] = sum_yy / (float)num_points;   // yy_avg
    params[5] = sum_zz / (float)num_points;   // zz_avg
    params[6] = sum_xy / (float)num_points;   // xy_avg
    params[7] = sum_xz / (float)num_points;   // xz_avg
    params[8] = sum_yz / (float)num_points;   // yz_avg
		params[9] = sum_xxx / (float)num_points;   // xxx_avg
		params[10] = sum_yyy / (float)num_points; // yyy_avg
		params[11] = sum_zzz / (float)num_points; // zzz_avg
		params[12] = sum_xxy / (float)num_points; // xxy_avg
		params[13] = sum_xxz / (float)num_points; // xxz_avg
		params[14] = sum_xyy / (float)num_points; // xyy_avg
		params[15] = sum_xzz / (float)num_points; // xzz_avg
		params[16] = sum_yyz / (float)num_points; // yyz_avg
		params[17] = sum_yzz / (float)num_points; // yzz_avg
		params[18] = sum_yyyy / (float)num_points; // yyyy_avg
		params[19] = sum_zzzz / (float)num_points; // zzzz_avg
		params[20] = sum_xxyy / (float)num_points; // xxyy_avg
		params[21] = sum_xxzz / (float)num_points; // xxzz_avg
		params[22] = sum_yyzz / (float)num_points; // yyzz_avg
		
    return 0;

}

void calculateEllipsoidParameters(float* result, float* center, float* radii) {
    float a1 = result[0], a2 = result[1];
    float x0 = -result[2] / 2;
    float y0 = -result[3] / (2 * a1);
    float z0 = -result[4] / (2 * a2);

    float radius_x = sqrt(x0 * x0 + a1 * y0 * y0 + a2 * z0 * z0 - result[5]);
    float radius_y = radius_x / sqrt(a1);
    float radius_z = radius_x / sqrt(a2);

    center[0] = x0;
    center[1] = y0;
    center[2] = z0;

    radii[0] = radius_x;
    radii[1] = radius_y;
    radii[2] = radius_z;
}

void calculateParam()
{
	short x[NUM_POINTS], y[NUM_POINTS], z[NUM_POINTS];  // 原始数据
	static int16_t magX, magY, magZ;
	
	for(int j=0;j<NUM_POINTS;j++)
	{
		LIS2MDL_ReadMagnetometer(&magX, &magY, &magZ);
		x[j]=magX;
		y[j]=magY;
		z[j]=magZ;
		HAL_Delay(500);
		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_14);
	}
	
	
	float params[23];
  calcAverages(x,y,z,NUM_POINTS, params);
	
	// 初始化系数矩阵 A
	float A[6][6] = {
			{params[18], params[22], params[14], params[10],  params[16], params[4]},  // yyyy_avg, yyzz_avg, xyy_avg, yyy_avg, yyz_avg, yy_avg
			{params[22], params[19], params[15], params[17], params[11], params[5]},  // yyzz_avg, zzzz_avg, xzz_avg, yzz_avg, zzz_avg, zz_avg
			{params[14], params[15], params[3],  params[6],  params[7],  params[0]},  // xyy_avg, xzz_avg, xx_avg,  xy_avg,  xz_avg,  x_avg
			{params[10],  params[17], params[6],  params[4],  params[8],  params[1]},  // yyy_avg, yzz_avg, xy_avg,  yy_avg,  yz_avg,  y_avg
			{params[16], params[11], params[7],  params[8],  params[5],  params[2]},  // yyz_avg, zzz_avg, xz_avg,  yz_avg,  zz_avg,  z_avg
			{params[4],  params[5],  params[0],  params[1],  params[2],  1.0f}        // yy_avg,  zz_avg,  x_avg,  y_avg,  z_avg,  1
	};
	
	// 初始化非齐次向量 b
	float b[6] = {
			-params[20],  // -xxyy_avg
			-params[21],  // -xxzz_avg
			-params[9],   // -xxx_avg
			-params[12],  // -xxy_avg
			-params[13],  // -xxz_avg
			-params[3]    // -xx_avg
	};
	
	
	
	
  float result[6];
  float inverse[6][6];
  matrix_inverse(A, inverse, 6);
	matrix__mul(inverse, b, result);
	
  float center[3], radii[3];
  calculateEllipsoidParameters(result, center, radii);
	
	Write_Float_to_EEPROM(center[0], 0);
	Write_Float_to_EEPROM(center[1], 1);
	Write_Float_to_EEPROM(center[2], 2);
	
	Write_Float_to_EEPROM(radii[0], 3);
	Write_Float_to_EEPROM(radii[1], 4);
	Write_Float_to_EEPROM(radii[2], 5);
}