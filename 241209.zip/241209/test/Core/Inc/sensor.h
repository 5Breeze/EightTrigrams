#ifndef __SENSOR_H__
#define __SENSOR_H__

#include "main.h"

#define LIS2MDL_I2C_ADDR  (0x1E << 1) 
#define LIS2DW12_I2C_ADDR  (0x19 << 1) 

extern I2C_HandleTypeDef hi2c1; // ȷ��I2C�ѳ�ʼ��

void LIS2DW12_InitForSingleConversion(void);
void LIS2DW12_ConfigActivityDetection(void);
void LIS2DW12_ReadAcceleration(int16_t *accX, int16_t *accY, int16_t *accZ);
void LIS2DW12_ReadSingleConversion(int16_t *accX, int16_t *accY, int16_t *accZ);
void LIS2MDL_Init(void);
void LIS2MDL_ReadMagnetometer(int16_t *magX, int16_t *magY, int16_t *magZ);
void I2C_Scan(uint8_t *found_devices, uint8_t *device_count);


#endif
