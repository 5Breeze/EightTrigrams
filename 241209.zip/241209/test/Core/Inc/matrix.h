#ifndef __MATRIX_H__
#define __MATRIX_H__

#include "main.h"
#include "math.h"
#include "data_storage.h"
#include "sensor.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MATRIX_SIZE 6 // ��������� 6x6 �Ĺ̶���С
#define NUM_POINTS 50  // ��������

void matrix_inverse(float src[MATRIX_SIZE][MATRIX_SIZE], float res[MATRIX_SIZE][MATRIX_SIZE], int size);
void matrix__mul(float matrix[MATRIX_SIZE][MATRIX_SIZE], float vector[MATRIX_SIZE], float result[MATRIX_SIZE]);
void calculateParam(void);
// ͳ�Ʋ���
float calcAverages(const short* x, const short* y, const short* z, int num_points, float* params);
void calculateEllipsoidParameters(float* result, float* center, float* radii);

#endif
